{extends "$layout"}

{block name="content"}
  <style>
    #hutkigrosh-completion-tabs .accordion-item { border-bottom: 1px solid #e5e5e5; }
    #hutkigrosh-completion-tabs .accordion-collapse { display: none; }
    #hutkigrosh-completion-tabs .accordion-collapse.show { display: block; }
    /* Заголовок вкладки в стиле темы classic (как .facet-title) */
    #hutkigrosh-completion-tabs .accordion-button {
      display: block;
      width: 100%;
      text-align: left;
      background: transparent;
      border: 0;
      padding: .875rem 0;
      font-size: 1rem;
      font-weight: 700;
      color: #232323;
      text-transform: uppercase;
      cursor: pointer;
    }
    #hutkigrosh-completion-tabs .accordion-button::after {
      content: "+";
      float: right;
      font-weight: 700;
      color: #7a7a7a;
    }
    #hutkigrosh-completion-tabs .accordion-button[aria-expanded="true"]::after { content: "\2212"; }
    #hutkigrosh-completion-tabs .accordion-body { padding: 0 0 1rem; }
  </style>
  <section id="content">
    {$completionPanel->build() nofilter}
  </section>
  <script src="{$smarty.const._MODULE_DIR_}ps_hutkigrosh_apiv3/views/js/completion.js"></script>
{/block}
