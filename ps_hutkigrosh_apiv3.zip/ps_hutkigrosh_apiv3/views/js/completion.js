/**
 * Переключение вкладок completion-панели ХуткиГрош.
 *
 * Вкладки построены как Bootstrap 5 accordion (accordion-item / accordion-button
 * с data-bs-toggle="collapse" / accordion-collapse). Но тема PrestaShop по умолчанию
 * не подключает JS Bootstrap 5, поэтому collapse при клике не срабатывает.
 *
 * Этот скрипт реализует переключение вручную:
 *   - инструкция открыта изначально (та вкладка, что имеет класс show);
 *   - клик по заголовку раскрывает соответствующее тело и сворачивает остальные.
 */
(function () {
    'use strict';

    function init() {
        var container = document.getElementById('hutkigrosh-completion-tabs');
        if (!container) {
            return;
        }
        var collapses = container.querySelectorAll('.accordion-collapse');
        if (!collapses.length) {
            return;
        }

        var buttons = container.querySelectorAll('.accordion-button');

        function show(collapseEl) {
            Array.prototype.forEach.call(collapses, function (c) {
                var isActive = (c === collapseEl);
                c.classList.toggle('show', isActive);
                c.style.display = isActive ? '' : 'none';
            });
            // Обновляем aria-expanded на кнопках (для иконки +/− в CSS).
            Array.prototype.forEach.call(buttons, function (btn) {
                var target = btn.getAttribute('data-bs-target');
                var c = target ? container.querySelector(target) : null;
                btn.setAttribute('aria-expanded', (c && c === collapseEl) ? 'true' : 'false');
            });
        }

        // Клик по кнопке-заголовку открывает соответствующее тело.
        Array.prototype.forEach.call(buttons, function (btn) {
            btn.addEventListener('click', function () {
                var target = btn.getAttribute('data-bs-target'); // #collapse{key}
                if (!target) {
                    return;
                }
                var collapseEl = container.querySelector(target);
                if (collapseEl) {
                    show(collapseEl);
                }
            });
        });

        // Изначально открываем вкладку с классом show (обычно — инструкция),
        // иначе — первую.
        var initial = container.querySelector('.accordion-collapse.show') || collapses[0];
        show(initial);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
