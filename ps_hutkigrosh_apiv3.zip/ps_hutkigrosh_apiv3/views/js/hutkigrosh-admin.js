/**
 * Клиентская логика кнопки "Актуализировать" на странице настроек ps_hutkigrosh.
 * По введённому API-токену запрашивает справочник услуг/торговых точек/касс
 * и заполняет соответствующие списки (Услуга / Розничная точка / Касса).
 */
(function () {
    /**
     * Кодирует строку в base64url (алфавит A-Za-z0-9-_, без символов +/=).
     * Применяется к JSON-справочнику metadata_json, чтобы в POST-теле формы
     * не было "голого" JSON (скобки/кавычки/спецсимволы в названиях), на котором
     * WAF хостинга блокировал сохранение настроек ("firewall policy violation").
     * UTF-8-безопасно (кириллица в названиях услуг/точек/касс).
     */
    function utf8ToBase64Url(str) {
        // encodeURIComponent -> ASCII-строка байтов UTF-8, затем btoa (без deprecated unescape).
        var b64 = btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, function (m, p1) {
            return String.fromCharCode(parseInt(p1, 16));
        }));
        return b64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    }

    document.addEventListener('DOMContentLoaded', function () {
        var globalData = null;

        var refreshBtn = document.querySelector('.hutkigrosh-actualize-btn');
        if (!refreshBtn) {
            return;
        }

        var serviceProviderUrl = refreshBtn.getAttribute('data-service-provider-url');
        var tokenField = refreshBtn.getAttribute('data-token-field');
        var serviceField = refreshBtn.getAttribute('data-service-field');
        var outletField = refreshBtn.getAttribute('data-outlet-field');
        var cashboxField = refreshBtn.getAttribute('data-cashbox-field');
        var sandboxField = refreshBtn.getAttribute('data-sandbox-field');
        var metadataField = refreshBtn.getAttribute('data-metadata-field');

        function fieldByName(name, tag) {
            if (!name) {
                return null;
            }
            return document.querySelector(tag + '[name="' + name + '"]');
        }

        var tokenInput = fieldByName(tokenField, 'input');
        var selectServices = fieldByName(serviceField, 'select');
        var selectOutlets = fieldByName(outletField, 'select');
        var selectCashboxes = fieldByName(cashboxField, 'select');
        var metadataInput = fieldByName(metadataField, 'input');
        var status = document.querySelector('.hutkigrosh-actualize-status');

        // Текущее значение sandbox-переключателя.
        // В PrestaShop switch рендерится как группа radio с одним именем.
        function currentSandbox() {
            if (!sandboxField) {
                return null;
            }
            var checked = document.querySelector('input[name="' + sandboxField + '"]:checked');
            if (checked) {
                return checked.value;
            }
            // fallback: обычный checkbox
            var cb = document.querySelector('input[name="' + sandboxField + '"]');
            return cb ? (cb.checked ? cb.value : '') : null;
        }

        function setOptionsEmpty() {
            if (selectServices) {
                selectServices.innerHTML = '<option value="">Нет данных</option>';
            }
            if (selectOutlets) {
                selectOutlets.innerHTML = '<option value="">Нет данных</option>';
            }
            if (selectCashboxes) {
                selectCashboxes.innerHTML = '<option value="">Нет данных</option>';
            }
        }

        function renderOptions(el, items) {
            var html = '';
            if (items && items.length > 0) {
                items.forEach(function (item) {
                    if (item.code !== undefined && item.name !== undefined) {
                        html += '<option value="' + item.code + '">' + item.name + '</option>';
                    }
                });
            }
            if (!html) {
                html = '<option value="">Нет данных</option>';
            }
            el.innerHTML = html;
        }

        function setLoading() {
            refreshBtn.disabled = true;
            refreshBtn.textContent = 'Загрузка...';
            if (status) {
                status.textContent = '';
            }
        }

        function setReady() {
            refreshBtn.disabled = false;
            refreshBtn.textContent = 'Актуализировать';
        }

        refreshBtn.addEventListener('click', function (e) {
            e.preventDefault();
            if (!tokenInput) {
                alert('Поле API Токен не найдено на странице');
                return;
            }
            var token = tokenInput.value.trim();
            if (!token) {
                alert('Сначала введите API Токен');
                return;
            }

            setLoading();
            if (selectServices) {
                selectServices.innerHTML = '<option>Загрузка...</option>';
            }
            if (selectOutlets) {
                selectOutlets.innerHTML = '<option>Загрузка...</option>';
            }
            if (selectCashboxes) {
                selectCashboxes.innerHTML = '<option>Загрузка...</option>';
            }

            var url = serviceProviderUrl
                + '?api_token=' + encodeURIComponent(token)
                + '&sandbox=' + encodeURIComponent(currentSandbox() === null ? '' : currentSandbox());

            var xhr = new XMLHttpRequest();
            xhr.open('GET', url, true);
            xhr.setRequestHeader('Accept', 'application/json');
            xhr.onload = function () {
                if (xhr.status >= 200 && xhr.status < 300) {
                    var data = null;
                    try {
                        data = JSON.parse(xhr.responseText);
                    } catch (err) {
                        alert('Некорректный ответ сервера');
                        setOptionsEmpty();
                        setReady();
                        return;
                    }
                    if (data && typeof data.message === 'undefined') {
                        globalData = data;
                        // Сохраняем справочник в скрытое поле, чтобы при следующем
                        // рендере формы списки имели опции и выбранные значения не терялись.
                        if (metadataInput) {
                            // В скрытое поле кладём base64url, а не голый JSON
                            // (см. ConfigFormPrestashopHutkigrosh::normalizeMetadataToJson).
                            metadataInput.value = utf8ToBase64Url(JSON.stringify(data));
                        }
                        if (selectServices) {
                            renderOptions(selectServices, data.services);
                        }
                        if (selectOutlets) {
                            renderOptions(selectOutlets, data.retailOutlets);
                        }
                        if (selectCashboxes) {
                            if (data.retailOutlets && data.retailOutlets.length > 0 && data.retailOutlets[0].cashBoxes) {
                                renderOptions(selectCashboxes, data.retailOutlets[0].cashBoxes);
                            } else {
                                renderOptions(selectCashboxes, []);
                            }
                        }
                        if (status) {
                            status.textContent = 'Данные загружены';
                            status.style.color = 'green';
                        }
                    } else {
                        var msg = (data && data.message) ? data.message : 'Неизвестная ошибка';
                        alert('Ошибка API или неверный токен. ' + msg);
                        setOptionsEmpty();
                    }
                } else {
                    alert('Ошибка соединения с сервером');
                    setOptionsEmpty();
                }
                setReady();
            };
            xhr.onerror = function () {
                alert('Ошибка соединения с сервером');
                setOptionsEmpty();
                setReady();
            };
            xhr.send();
        });

        // При смене розничной точки — перестроить список касс под неё
        if (selectOutlets) {
            selectOutlets.addEventListener('change', function () {
                if (!globalData || !selectCashboxes) {
                    return;
                }
                var selectedCode = this.value;
                var outlet = null;
                if (globalData.retailOutlets) {
                    for (var i = 0; i < globalData.retailOutlets.length; i++) {
                        if (globalData.retailOutlets[i].code == selectedCode) {
                            outlet = globalData.retailOutlets[i];
                            break;
                        }
                    }
                }
                renderOptions(selectCashboxes, (outlet && outlet.cashBoxes) ? outlet.cashBoxes : []);
            });
        }
    });
})();
