<?php
require_once(dirname(dirname(dirname(__FILE__))) . '/init.php');

use esas\cmsgate\ConfigFields;
use esas\cmsgate\hutkigrosh\protocol\HutkigroshProtocol;
use esas\cmsgate\hutkigrosh\RegistryHutkigrosh;
use esas\cmsgate\utils\Logger;

/**
 * AJAX-endpoint для кнопки "Актуализировать" на странице настроек.
 * По переданному из формы api_token запрашивает справочник услуг/точек/касс
 * (service-provider/metadata) и возвращает его в виде JSON.
 *
 * @since 1.5.0
 */
class Ps_hutkigrosh_apiv3ActualizeModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();
        $this->ajax = true; // включаем ajax-режим
    }

    /**
     * displayAjax — обязательное имя метода для ajax-ответа
     */
    public function displayAjax()
    {
        header('Content-Type: application/json; charset=utf-8');
        try {
            $apiToken = trim((string)Tools::getValue('api_token', ''));
            if ($apiToken === '') {
                $this->jsonError(400, 'API Token is required');
                return;
            }

            // Sandbox-режим: сначала из формы (актуальное значение чекбокса),
            // иначе из сохранённого конфигурацией.
            $sandboxParam = Tools::getValue('sandbox');
            if ($sandboxParam !== false && $sandboxParam !== null) {
                $sandbox = in_array(strtolower((string)$sandboxParam), ['1', 'true', 'on', 'yes', 'y']);
            } else {
                $sandbox = (bool)RegistryHutkigrosh::getRegistry()->getConfigWrapper()->getConfig(ConfigFields::sandbox());
            }

            // Базовый URL берём из констант протокола (рабочий/тестовый)
            $apiUrl = $sandbox ? HutkigroshProtocol::API_URL_TEST : HutkigroshProtocol::API_URL;
            $url = $apiUrl . 'service-provider/metadata?api-version=3.0';

            $ch = curl_init();
            curl_setopt_array($ch, array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER => array(
                    'Content-Type: application/json',
                    'Authorization: Bearer ' . $apiToken,
                ),
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_TIMEOUT => 30,
            ));

            $response = curl_exec($ch);
            $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = curl_error($ch);
            curl_close($ch);

            if ($curlError) {
                $this->jsonError(500, 'cURL error: ' . $curlError);
                return;
            }

            $data = json_decode($response, true);
            if ($httpCode >= 400) {
                $this->jsonError($httpCode, ($data && !empty($data['message'])) ? $data['message'] : ('API error HTTP ' . $httpCode));
                return;
            }

            // Возвращаем сырой ответ шлюза (services / retailOutlets с cashBoxes)
            echo json_encode($data);
        } catch (Throwable $e) {
            Logger::getLogger("actualize")->error("Exception:", $e);
            $this->jsonError(500, $e->getMessage());
        } catch (Exception $e) { // для совместимости с php 5
            Logger::getLogger("actualize")->error("Exception:", $e);
            $this->jsonError(500, $e->getMessage());
        }
    }

    /**
     * Выводит JSON-ошибку с заданным HTTP-кодом и завершает выполнение.
     * @param int $code
     * @param string $message
     */
    private function jsonError($code, $message)
    {
        http_response_code((int)$code);
        echo json_encode(array('message' => $message));
        die;
    }
}
