<?php
/**
 * Расширение ConfigFormPrestashop для модуля ps_hutkigrosh.
 *
 * Добавляет под полем "API Токен":
 *  - кнопку "Актуализировать", которая через AJAX тянет справочник услуг/торговых
 *    точек/касс (service-provider/metadata) и заполняет списки;
 *  - скрытое поле metadata_json, хранящее полученный справочник между сохранениями.
 *
 * Справочник из metadata_json используется для построения опций списков Услуга /
 * Розничная точка / Касса при рендере формы — благодаря этому ранее выбранные
 * значения не "теряются" после перезагрузки страницы (поведение как в примере
 * Drupal commerce_hutkigrosh).
 */

namespace esas\cmsgate\view\admin;

use Configuration;
use esas\cmsgate\ConfigFields;
use esas\cmsgate\hutkigrosh\ConfigFieldsHutkigrosh;
use Link;

class ConfigFormPrestashopHutkigrosh extends ConfigFormPrestashop
{
    /**
     * Локальный ключ, под которым хранится JSON-справочник (CMS-зависимый).
     * @return string
     */
    private static function metadataKey()
    {
        return ConfigFields::getCmsRelatedKey("metadata_json");
    }

    /**
     * Кодирует JSON-справочник в base64url для скрытого поля формы.
     * base64url убирает из POST-тела символы JSON ({ } [ ] " : ,) и спецсимволы
     * в названиях услуг/точек/касс, из-за которых WAF хостинга блокировал
     * сохранение настроек ("firewall policy violation").
     * @param string $json
     * @return string
     */
    private static function encodeMetadata($json)
    {
        $json = (string)$json;
        if ($json === '') {
            return '';
        }
        // PHP base64_encode работает с байтами, UTF-8 (кириллица) кодируется корректно.
        return rtrim(strtr(base64_encode($json), '+/', '-_'), '=');
    }

    /**
     * Приводит значение скрытого поля metadata_json к обычному JSON для хранения в БД.
     * Из формы ожидается base64url; для обратной совместимости допускается и "голый"
     * JSON (если форма была отрисована старой версией кода без кодирования).
     * @param string $value
     * @return string JSON (возможно, пустая строка)
     */
    private static function normalizeMetadataToJson($value)
    {
        $value = (string)$value;
        if ($value === '') {
            return '';
        }
        // Уже валидный JSON — отдаём как есть (обратная совместимость).
        if (json_decode($value, true) !== null) {
            return $value;
        }
        // Иначе пытаемся разобрать как base64url -> стандартный base64 -> JSON.
        $standard = strtr($value, '-_', '+/');
        $mod = strlen($standard) % 4;
        if ($mod !== 0) {
            $standard .= str_repeat('=', 4 - $mod); // восстанавливаем padding
        }
        $decoded = base64_decode($standard, true);
        if ($decoded !== false && json_decode($decoded, true) !== null) {
            return $decoded;
        }
        // Не удалось разобрать — сохраняем как есть, чтобы не потерять данные.
        return $value;
    }

    /**
     * Формирует индексный массив полей формы: под полем "API Токен" вставляет
     * кнопку "Актуализировать" и скрытое поле metadata_json, а опции списков
     * Услуга / Розничная точка / Касса наполняет из сохранённого справочника.
     * @return array
     */
    public function generateFields()
    {
        $fields = parent::generateFields(); // индексный массив от ConfigFormPrestashop
        $result = array();
        foreach ($fields as $fieldDef) {
            $result[] = $fieldDef;
            if (isset($fieldDef['name']) && $fieldDef['name'] === ConfigFieldsHutkigrosh::apiToken()) {
                $result[] = $this->generateActualizeButton();
                $result[] = $this->generateMetadataField();
            }
        }
        return $this->applyMetadataOptions($result);
    }

    /**
     * Сохраняет настройки формы, включая скрытое поле metadata_json.
     * @throws \Throwable
     */
    public function save()
    {
        parent::save(); // сохраняет все управляемые поля (Услуга/Точка/Касса и т.д.)
        $key = self::metadataKey();
        // Форма присылает справочник в base64url (см. hutkigrosh-admin.js),
        // а в БД храним обычный JSON (читаемо при отладке). html=false, т.к. JSON.
        if (array_key_exists($key, $_REQUEST)) {
            $json = self::normalizeMetadataToJson((string)$_REQUEST[$key]);
            Configuration::updateValue($key, $json, false);
        }
    }

    /**
     * Кнопка "Актуализировать" + область статуса + подключение клиентского JS.
     * Точные имена полей передаются серверно (через data-атрибуты), чтобы не
     * хардкодить CMS-зависимые ключи в JS.
     * @return array
     */
    private function generateActualizeButton()
    {
        $endpointUrl = (new Link())->getModuleLink('ps_hutkigrosh_apiv3', 'actualize', array(), true);
        $jsUrl = _MODULE_DIR_ . 'ps_hutkigrosh_apiv3/views/js/hutkigrosh-admin.js';

        $dataAttrs = sprintf(
            'data-service-provider-url="%1$s" data-token-field="%2$s" data-service-field="%3$s" data-outlet-field="%4$s" data-cashbox-field="%5$s" data-sandbox-field="%6$s" data-metadata-field="%7$s"',
            htmlspecialchars($endpointUrl, ENT_QUOTES),
            htmlspecialchars(ConfigFieldsHutkigrosh::apiToken(), ENT_QUOTES),
            htmlspecialchars(ConfigFieldsHutkigrosh::serviceId(), ENT_QUOTES),
            htmlspecialchars(ConfigFieldsHutkigrosh::retailOutletId(), ENT_QUOTES),
            htmlspecialchars(ConfigFieldsHutkigrosh::cashboxId(), ENT_QUOTES),
            htmlspecialchars(ConfigFields::sandbox(), ENT_QUOTES),
            htmlspecialchars(self::metadataKey(), ENT_QUOTES)
        );

        $html = '<div class="hutkigrosh-actualize-block" style="margin-bottom:10px">'
            . '<button type="button" class="btn btn-default hutkigrosh-actualize-btn" ' . $dataAttrs . '>'
            . 'Актуализировать</button>'
            . '<span class="hutkigrosh-actualize-status" style="margin-left:10px"></span>'
            . '</div>'
            . '<script src="' . htmlspecialchars($jsUrl, ENT_QUOTES) . '"></script>';

        return array(
            'type' => 'html',
            'name' => 'hutkigrosh_actualize',
            'html_content' => $html,
        );
    }

    /**
     * Скрытое поле metadata_json: хранит справочник, полученный при актуализации.
     * Значение вшивается прямо в HTML (не зависит от fields_value HelperForm).
     * @return array
     */
    private function generateMetadataField()
    {
        $key = self::metadataKey();
        $json = (string)Configuration::get($key); // в БД хранится обычный JSON
        $encoded = self::encodeMetadata($json);   // в скрытое поле формы — base64url
        $html = '<input type="hidden" name="' . htmlspecialchars($key, ENT_QUOTES) . '"'
            . ' class="hutkigrosh-metadata-json"'
            . ' value="' . htmlspecialchars($encoded, ENT_QUOTES) . '" />';

        return array(
            'type' => 'html',
            'name' => 'hutkigrosh_metadata',
            'html_content' => $html,
        );
    }

    /**
     * Для списков Услуга / Розничная точка / Касса добавляет опции из сохранённого
     * справочника metadata_json, чтобы ранее выбранные значения отображались.
     * @param array $fields
     * @return array
     */
    private function applyMetadataOptions(array $fields)
    {
        $data = $this->getStoredMetadata();
        if (empty($data)) {
            return $fields;
        }
        foreach ($fields as &$def) {
            if (!isset($def['name'], $def['options']['query'])) {
                continue;
            }
            if ($def['name'] === ConfigFieldsHutkigrosh::serviceId() && !empty($data['services'])) {
                $this->mergeOptions($def, $this->optionsFromItems($data['services']));
            } elseif ($def['name'] === ConfigFieldsHutkigrosh::retailOutletId() && !empty($data['retailOutlets'])) {
                $this->mergeOptions($def, $this->optionsFromItems($data['retailOutlets']));
            } elseif ($def['name'] === ConfigFieldsHutkigrosh::cashboxId() && !empty($data['retailOutlets'])) {
                $this->mergeOptions($def, $this->optionsFromCashboxes($data['retailOutlets']));
            }
        }
        unset($def);
        return $fields;
    }

    /**
     * Дописывает к существующим опциям списка новые (placeholder сохраняется первым).
     * @param array $def
     * @param array $newOptions
     */
    private function mergeOptions(array &$def, array $newOptions)
    {
        if (empty($newOptions)) {
            return;
        }
        $def['options']['query'] = array_merge($def['options']['query'], $newOptions);
    }

    /**
     * Опции из простого списка {code,name}.
     * @param array $items
     * @return array
     */
    private function optionsFromItems($items)
    {
        $opts = array();
        if (!is_array($items)) {
            return $opts;
        }
        foreach ($items as $item) {
            if (is_array($item) && isset($item['code'], $item['name'])) {
                $opts[] = array('id' => $item['code'], 'name' => $item['name']);
            }
        }
        return $opts;
    }

    /**
     * Опции кассовых мест — собираются из всех розничных точек (как buildCashboxOptions в примере).
     * @param array $outlets
     * @return array
     */
    private function optionsFromCashboxes($outlets)
    {
        $opts = array();
        if (!is_array($outlets)) {
            return $opts;
        }
        foreach ($outlets as $outlet) {
            if (!is_array($outlet) || empty($outlet['cashBoxes'])) {
                continue;
            }
            foreach ($outlet['cashBoxes'] as $box) {
                if (is_array($box) && isset($box['code'], $box['name'])) {
                    $opts[] = array('id' => $box['code'], 'name' => $box['name']);
                }
            }
        }
        return $opts;
    }

    /**
     * @return array|null Разобранный справочник или null
     */
    private function getStoredMetadata()
    {
        $raw = Configuration::get(self::metadataKey());
        if (empty($raw)) {
            return null;
        }
        $data = json_decode($raw, true);
        return is_array($data) ? $data : null;
    }
}
