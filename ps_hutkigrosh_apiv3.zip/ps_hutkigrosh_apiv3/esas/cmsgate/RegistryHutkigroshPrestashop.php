<?php
/**
 * Created by IntelliJ IDEA.
 * User: nikit
 * Date: 15.07.2019
 * Time: 11:22
 */

namespace esas\cmsgate;

use Context;
use esas\cmsgate\descriptors\ModuleDescriptor;
use esas\cmsgate\descriptors\VendorDescriptor;
use esas\cmsgate\descriptors\VersionDescriptor;
use esas\cmsgate\hutkigrosh\ConfigFieldsHutkigrosh;
use esas\cmsgate\hutkigrosh\PaysystemConnectorHutkigrosh;
use esas\cmsgate\hutkigrosh\RegistryHutkigrosh;
use esas\cmsgate\hutkigrosh\utils\RequestParamsHutkigrosh;
use esas\cmsgate\properties\ViewProperties;
use esas\cmsgate\view\admin\AdminViewFields;
use esas\cmsgate\view\admin\ConfigFormPrestashop;
use esas\cmsgate\view\admin\ConfigFormPrestashopHutkigrosh;
use Link;

class RegistryHutkigroshPrestashop extends RegistryHutkigrosh
{
    public function __construct()
    {
        $this->cmsConnector = new CmsConnectorPrestashop();
        $this->paysystemConnector = new PaysystemConnectorHutkigrosh();
    }

    /**
     * Переопделение для упрощения типизации
     * @return RegistryHutkigroshPrestashop
     */
    public static function getRegistry()
    {
        return parent::getRegistry();
    }

    /**
     * Переопделение для упрощения типизации
     * @return ConfigFormPrestashop
     */
    public function getConfigForm()
    {
        return parent::getConfigForm();
    }

    public function createConfigForm()
    {
        $managedFields = $this->getManagedFieldsFactory()->getManagedFieldsExcept(AdminViewFields::CONFIG_FORM_COMMON,
            [
                ConfigFieldsHutkigrosh::shopName()
            ]);
        $configForm = new ConfigFormPrestashopHutkigrosh(
            AdminViewFields::CONFIG_FORM_COMMON,
            $managedFields);
        return $configForm;
    }

    function getUrlWebpay($orderWrapper)
    {
        return (new Link())->getModuleLink(RegistryHutkigrosh::getRegistry()->getModuleDescriptor()->getModuleMachineName(), 'payment', array(RequestParamsHutkigrosh::ORDER_NUMBER => $orderWrapper->getOrderNumber())) ;
    }

    /**
     * Свойства отображения (версия Bootstrap).
     * CompletionPanel (аккордеон, alert-dismissible) использует классы Bootstrap 5.
     * Без этого метода рендер любых warning/error-сообщений панели падает с
     * "Not implemented" (Registry::getProperties()), что приводит к HTTP 500.
     */
    public function createProperties()
    {
        return new class implements ViewProperties {
            public function getBootstrapVersion()
            {
                return ViewProperties::BOOTSTRAP_V5;
            }
        };
    }

    public function createModuleDescriptor()
    {
        return new ModuleDescriptor(
            "ps_hutkigrosh_apiv3",
            new VersionDescriptor("3.0.1", "2026-08-05"),
            "Прием платежей через ЕРИП (ХуткиГрош, API v3)",
            "https://bitbucket.esas.by/projects/CG/repos/cmsgate-prestashop-hutkigrosh/browse",
            VendorDescriptor::esas(),
            "Выставление пользовательских счетов в ЕРИП"
        );
    }
}